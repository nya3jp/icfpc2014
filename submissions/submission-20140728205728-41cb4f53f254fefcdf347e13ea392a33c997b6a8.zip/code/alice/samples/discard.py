def main():
  unpair((2, 3))
  3
