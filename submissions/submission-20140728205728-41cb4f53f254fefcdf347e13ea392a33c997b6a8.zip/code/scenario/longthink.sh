./simulator/simulator ./map/tiny2.map ./LambdaMan/cornercase-longthink.gcc ghost/scatter.ghc

