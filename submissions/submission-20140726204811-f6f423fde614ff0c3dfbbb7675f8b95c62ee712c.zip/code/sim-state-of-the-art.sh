./sim.sh --map=map/train.map --lambda=state-of-the-art.gcc --ghost=ghost/chase_with_random.ghc,ghost/scatter.ghc,ghost/random_and_chase.ghc
