while true
do
    time  ./LambdaManP/dist/build/aznyan-bokujo/aznyan-bokujo
done;
