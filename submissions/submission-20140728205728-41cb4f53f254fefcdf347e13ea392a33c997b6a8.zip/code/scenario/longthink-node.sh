./sim.sh --map=map/tiny2.map --lambda=LambdaMan/cornercase-longthink.gcc --ghost=ghost/chase_fixed.ghc
