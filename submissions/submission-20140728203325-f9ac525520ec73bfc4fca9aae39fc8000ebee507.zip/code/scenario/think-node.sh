./sim.sh --map=map/tiny2.map --lambda=LambdaMan/cornercase-think.gcc --ghost=ghost/chase_fixed.ghc
