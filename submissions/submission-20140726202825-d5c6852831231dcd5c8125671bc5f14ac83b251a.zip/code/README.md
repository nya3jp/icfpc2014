icfpc2014
=========

Environments
------------

* CI server: `ssh einclad.coders.jp`
* Jenkins Web UI: http://einclad.coders.jp/ einclad:asunyan

http://blogs.c.yimg.jp/res/blog-b8-52/fujisyuu01/folder/376855/78/6706678/img_0

