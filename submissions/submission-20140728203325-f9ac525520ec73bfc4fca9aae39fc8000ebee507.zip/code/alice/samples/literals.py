def main():
  print [1, 2, 3]
  print (8, 9, 10)
