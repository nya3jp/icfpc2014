main = putStrLn "こころがぴょんぴょんするんじゃあ＾〜〜〜" >> main
