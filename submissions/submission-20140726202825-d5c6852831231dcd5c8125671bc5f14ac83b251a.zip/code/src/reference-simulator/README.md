Reference Simulator CUI
=======================

Usage:
node simulator.js --map=map.txt --lambda=lambda.txt --ghost=ghost.txt
