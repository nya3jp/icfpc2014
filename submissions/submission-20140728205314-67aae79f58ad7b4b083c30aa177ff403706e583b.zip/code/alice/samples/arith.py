def main():
  print 14 + 3
  print 14 - 3
  print 14 * 3
  print 14 / 3
