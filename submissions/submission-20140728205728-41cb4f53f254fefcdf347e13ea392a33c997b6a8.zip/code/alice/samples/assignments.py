def main():
  # defaults to 0
  print a

  a = 7
  a *= 6
  print a
