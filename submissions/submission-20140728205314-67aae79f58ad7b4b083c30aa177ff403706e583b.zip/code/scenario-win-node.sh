./sim.sh --map=map/tiny.map --lambda=LambdaMan/akippoi-aznyan.gcc --ghost=ghost/chase_fixed.ghc
