type direction =
  | Up
  | Right
  | Down
  | Left
