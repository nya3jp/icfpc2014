rsync -avz LambdaMan/gen2/ nushio@einclad.coders.jp:gen2/
